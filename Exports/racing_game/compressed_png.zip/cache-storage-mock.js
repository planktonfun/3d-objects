// Simple global cache
const memoryCache = {};

// Simplified mock
const caches = {
async open(cacheKey) {
    if (!memoryCache[cacheKey]) {
        memoryCache[cacheKey] = {
            store: new Map(),
            async match(url) {
                return this.store.get(url) || null;
            },
            async put(url, response) {
                this.store.set(url, response.clone());
            }
        };
    }
    return memoryCache[cacheKey];
}
};

// Now your fetchGitCache and fetchCache functions will work with the mock