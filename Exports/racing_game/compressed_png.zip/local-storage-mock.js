// ============================================
      // MOCK localStorage
      // ============================================
      class MockStorage {
        constructor() {
          this.store = new Map();
          this.length = 0;
        }

        getItem(key) {
          return this.store.get(key) || null;
        }

        setItem(key, value) {
          this.store.set(key, String(value));
          this.length = this.store.size;
        }

        removeItem(key) {
          this.store.delete(key);
          this.length = this.store.size;
        }

        clear() {
          this.store.clear();
          this.length = 0;
        }

        key(index) {
          const keys = Array.from(this.store.keys());
          return keys[index] || null;
        }

        // For debugging
        getAll() {
          return Object.fromEntries(this.store);
        }
      }

      // Replace localStorage with mock if not available
      window.localStorageMock = new MockStorage();