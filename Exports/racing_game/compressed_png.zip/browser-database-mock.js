class BrowserDatabase {
  constructor(dbName, objectStoreName) {
    this.dbName = dbName;
    this.objectStoreName = objectStoreName;
    this.db = null;
    // In-memory storage
    this.dataStore = new Map();
    this.nextId = 1;
    this.isOpen = false;
  }

  deleteDatabase() {
    return new Promise((resolve, reject) => {
      try {
        // Clear all data
        this.dataStore.clear();
        this.nextId = 1;
        this.isOpen = false;
        this.db = null;
        resolve("Database deleted successfully", this.dbName);
      } catch (error) {
        reject("Error deleting database.", this.dbName);
      }
    });
  }

  openConnection() {
    return new Promise((resolve, reject) => {
      try {
        this.db = { name: this.dbName };
        this.isOpen = true;
        resolve();
      } catch (error) {
        reject(error);
      }
    });
  }

  setDataById(key, data) {
    return new Promise((resolve, reject) => {
      try {
        if (!this.isOpen) {
          reject(new Error("Database not open"));
          return;
        }
        this.dataStore.set(key, { id: key, data });
        resolve();
      } catch (error) {
        reject(error);
      }
    });
  }

  insertRow(data) {
    return new Promise((resolve, reject) => {
      try {
        if (!this.isOpen) {
          reject(new Error("Database not open"));
          return;
        }
        // Auto-increment ID
        const id = this.nextId++;
        const record = { ...data, id };
        this.dataStore.set(id, record);
        resolve();
      } catch (error) {
        reject(error);
      }
    });
  }

  getDataById(recordId) {
    return new Promise((resolve, reject) => {
      try {
        if (!this.isOpen) {
          reject(new Error("Database not open"));
          return;
        }
        const data = this.dataStore.get(recordId);
        resolve(data || null);
      } catch (error) {
        reject(error);
      }
    });
  }

  deleteByKey(recordId) {
    return new Promise((resolve, reject) => {
      try {
        if (!this.isOpen) {
          reject(new Error("Database not open"));
          return;
        }
        const deleted = this.dataStore.delete(recordId);
        if (deleted) {
          resolve("success");
        } else {
          reject("Record not found.");
        }
      } catch (error) {
        reject(error);
      }
    });
  }

  async deleteAllData() {
    try {
      const keys = await this.getAllKeys();
      for (const key of keys) {
        await this.deleteByKey(key);
      }
    } catch (error) {
      throw error;
    }
  }

  getAllKeys() {
    return new Promise((resolve, reject) => {
      try {
        if (!this.isOpen) {
          reject(new Error("Database not open"));
          return;
        }
        const keys = Array.from(this.dataStore.keys());
        resolve(keys);
      } catch (error) {
        reject(error);
      }
    });
  }

  getAllData() {
    return new Promise((resolve, reject) => {
      try {
        if (!this.isOpen) {
          reject(new Error("Database not open"));
          return;
        }
        const data = Array.from(this.dataStore.values());
        resolve(data);
      } catch (error) {
        reject(error);
      }
    });
  }
}